// Generate falling emojis
const emojis = ["😈", "🔥", "💪", "💯", "👑"];
const body = document.body;

function createEmoji() {
  const emoji = document.createElement("div");
  emoji.classList.add("emoji");
  emoji.style.left = Math.random() * 100 + "vw";
  emoji.style.animationDuration = (5 + Math.random() * 5) + "s";
  emoji.textContent = emojis[Math.floor(Math.random() * emojis.length)];
  body.appendChild(emoji);

  // Remove emoji after animation
  setTimeout(() => {
    emoji.remove();
  }, 8000);
}

setInterval(createEmoji, 300);

// Follow button alert
document.getElementById("followButton").addEventListener("click", () => {
  alert("🔥 Thanks for following Codemafia Squad!");
});